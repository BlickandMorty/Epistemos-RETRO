/* tslint:disable */
/* eslint-disable */

export class SpringConfig {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    damping: number;
    mass: number;
    stiffness: number;
}

export class SpringEngine {
    free(): void;
    [Symbol.dispose](): void;
    get_value(id: string): number;
    is_resting(id: string): boolean;
    constructor();
    register_spring(id: string, initial_val: number, stiffness: number, damping: number, mass: number): void;
    set_target(id: string, target: number): void;
    set_value(id: string, value: number): void;
    tick(dt_ms: number): void;
    unregister_spring(id: string): void;
}

export class SpringState {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    target: number;
    value: number;
    velocity: number;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_get_springconfig_damping: (a: number) => number;
    readonly __wbg_get_springconfig_mass: (a: number) => number;
    readonly __wbg_get_springconfig_stiffness: (a: number) => number;
    readonly __wbg_set_springconfig_damping: (a: number, b: number) => void;
    readonly __wbg_set_springconfig_mass: (a: number, b: number) => void;
    readonly __wbg_set_springconfig_stiffness: (a: number, b: number) => void;
    readonly __wbg_springconfig_free: (a: number, b: number) => void;
    readonly __wbg_springengine_free: (a: number, b: number) => void;
    readonly __wbg_springstate_free: (a: number, b: number) => void;
    readonly springengine_get_value: (a: number, b: number, c: number) => number;
    readonly springengine_is_resting: (a: number, b: number, c: number) => number;
    readonly springengine_new: () => number;
    readonly springengine_register_spring: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly springengine_set_target: (a: number, b: number, c: number, d: number) => void;
    readonly springengine_set_value: (a: number, b: number, c: number, d: number) => void;
    readonly springengine_tick: (a: number, b: number) => void;
    readonly springengine_unregister_spring: (a: number, b: number, c: number) => void;
    readonly __wbg_set_springstate_target: (a: number, b: number) => void;
    readonly __wbg_set_springstate_value: (a: number, b: number) => void;
    readonly __wbg_set_springstate_velocity: (a: number, b: number) => void;
    readonly __wbg_get_springstate_target: (a: number) => number;
    readonly __wbg_get_springstate_value: (a: number) => number;
    readonly __wbg_get_springstate_velocity: (a: number) => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;

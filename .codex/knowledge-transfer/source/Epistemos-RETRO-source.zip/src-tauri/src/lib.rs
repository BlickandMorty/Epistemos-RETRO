mod commands;
mod error;
mod state;

use commands::{notes, chat, folders, graph, physics, research, search, vault, system};
use state::AppState;
use storage::db::Database;
use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri_specta::Builder::<tauri::Wry>::new()
        .commands(tauri_specta::collect_commands![
            notes::create_page,
            notes::get_page,
            notes::list_pages,
            notes::update_page,
            notes::delete_page,
            notes::load_body,
            notes::save_body,
            notes::get_blocks,
            notes::generate_note_ai,
            chat::create_chat,
            chat::list_chats,
            chat::get_messages,
            chat::delete_chat,
            chat::submit_query,
            chat::run_soar_stone,
            chat::cancel_query,
            graph::get_graph,
            graph::rebuild_graph,
            graph::search_graph,
            graph::extract_entities,
            graph::get_node_details,
            graph::summarize_node,
            graph::set_node_embedding,
            graph::semantic_neighbors,
            graph::semantic_similarity,
            folders::create_folder,
            folders::get_folder,
            folders::list_folders,
            folders::update_folder,
            folders::delete_folder,
            search::search_pages,
            search::rebuild_search_index,
            search::search_hybrid,
            vault::get_vault_path,
            vault::set_vault_path,
            vault::import_vault,
            vault::export_page,
            vault::export_all,
            vault::start_vault_watcher,
            vault::stop_vault_watcher,
            vault::is_vault_watching,
            system::get_inference_config,
            system::set_inference_config,
            system::test_connection,
            system::get_app_info,
            system::check_local_services,
            system::get_local_model_config,
            system::set_local_model_config,
            system::get_cost_summary,
            system::set_daily_budget,
            system::reset_cost_tracker,
            system::get_embedding_status,
            system::embed_text,
            system::find_similar_nodes,
            physics::start_physics,
            physics::stop_physics,
            physics::pin_node,
            physics::unpin_node,
            physics::move_node,
            physics::is_physics_running,
            physics::toggle_fps_mode,
            physics::fps_input,
            physics::get_physics_mode,
            physics::set_physics_target_fps,
            research::start_research,
            research::advance_research,
            research::get_research_status,
        ]);

    #[cfg(debug_assertions)]
    builder
        .export(
            specta_typescript::Typescript::default()
                .bigint(specta_typescript::BigIntExportBehavior::Number),
            "../src/lib/bindings.ts",
        )
        .expect("Failed to export typescript bindings");

    // Use a shared slot so we can reference AppState in the exit handler.
    let state_slot: std::sync::Arc<std::sync::Mutex<Option<AppState>>> =
        std::sync::Arc::new(std::sync::Mutex::new(None));
    let state_for_exit = state_slot.clone();

    let app = tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(builder.invoke_handler())
        .setup(move |app| {
            builder.mount_events(app);

            let app_data = app.path().app_data_dir()
                .expect("failed to resolve app data directory");
            std::fs::create_dir_all(&app_data)
                .expect("failed to create app data directory");
            let db_path = app_data.join("epistemos.db");

            let db = Database::open(&db_path)
                .expect("failed to open database");
            let state = AppState::new(db);

            app.manage(state.clone());

            // Store state reference for graceful shutdown handler.
            if let Ok(mut slot) = state_slot.lock() {
                *slot = Some(state.clone());
            }

            // Background: pre-load graph + probe AI services.
            // Both are non-critical for initial render — the window opens immediately.
            let graph_state = state.clone();
            std::thread::spawn(move || {
                if let Err(e) = graph_state.reload_graph() {
                    eprintln!("[WARN][startup] failed to pre-load graph — search will be degraded: {e}");
                }
            });

            tauri::async_runtime::spawn(async move {
                if let Err(e) = system::probe_and_cache_services(&state).await {
                    eprintln!("[WARN][startup] failed to probe local AI services — triage routing may default to cloud: {e}");
                }
            });

            Ok(())
        })
        .build(tauri::generate_context!())
        .expect("error while building tauri application");

    app.run(move |_app_handle, event| {
        if let tauri::RunEvent::Exit = event {
            // Graceful shutdown: cancel all tracked tasks and wait for cleanup.
            if let Ok(guard) = state_for_exit.lock() {
                if let Some(state) = guard.as_ref() {
                    eprintln!("[shutdown] cancelling background tasks...");
                    state.shutdown_token.cancel();
                    // Block briefly to let tasks wind down.
                    // We can't async-await here, so use a short spin.
                    let handles_exist = state.task_handles.lock()
                        .map(|h| !h.is_empty())
                        .unwrap_or(false);
                    if handles_exist {
                        std::thread::sleep(std::time::Duration::from_millis(500));
                    }
                    eprintln!("[shutdown] done");
                }
            }
        }
    });
}
